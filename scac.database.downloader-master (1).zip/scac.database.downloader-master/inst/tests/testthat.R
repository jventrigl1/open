library(testthat)
library(risklists)

test_check("risklists")
