# SCAC Database Downloader Package

scac.database.downloader

Download the contents of the Stanford [SCAC (Stanford Securities Class Action Clearinghouse)](http://securities.stanford.edu/) in tabular form for analysis in R.

